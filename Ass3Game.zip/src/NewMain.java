import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.*;

public class NewMain {

    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }

}
