public class Block implements Collidable {
    private Rectangle CollisionRectangle;

    // Return the "collision shape" of the object.
    public Rectangle getCollisionRectangle() {
        return this.CollisionRectangle;
    }

    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        
        // if the collision is with a horizontal side of the "Block" (can be also with a vertical side)
        if (this.CollisionRectangle.getUpperLeft().getY() == collisionPoint.getY()) {
            currentVelocity = new Velocity(currentVelocity.getDx(), (-1) * currentVelocity.getDy());
        } else if (this.CollisionRectangle.lowerLeft().getY() == collisionPoint.getY()) {
            currentVelocity = new Velocity(currentVelocity.getDx(), (-1) * currentVelocity.getDy());
        }

        // if the collision is with a vertical side of the "Block" (can be also with a horizontal side)
        if (this.CollisionRectangle.getUpperLeft().getX() == collisionPoint.getX()) {
            currentVelocity = new Velocity((-1) * currentVelocity.getDx(), currentVelocity.getDy());
        } else if (this.CollisionRectangle.upperRight().getX() == collisionPoint.getX()) {
            currentVelocity = new Velocity((-1) * currentVelocity.getDx(), currentVelocity.getDy());
        }

        return currentVelocity;
    }
}
