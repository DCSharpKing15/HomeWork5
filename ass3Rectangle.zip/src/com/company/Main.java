package com.company;

//import javax.sound.sampled.Line;

import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Point s1 = new Point(0, 0);
        Point e1 = new Point(0, 6);
        Point s2 = new Point(3, 1);
        Point e2 = new Point(3, 6);
        //Line l1=new Line(s1,e1);
        //Line l2=new Line(3,1,3,6);


    }
}
