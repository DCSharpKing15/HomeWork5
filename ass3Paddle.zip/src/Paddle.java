import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;

import java.awt.*;

public class Paddle implements Sprite, Collidable {
    private KeyboardSensor keyboard;
    private Block block;
    private Color color;

    public Paddle(GUI gui) {
        this.keyboard = gui.getKeyboardSensor();
        this.color = Color.cyan;
        this.block = new Block(new Rectangle(new Point(375, 530), 50, 20), color);
    }

    public void moveLeft() {
        this.block = new Block(new Rectangle(new Point(this.block.getCollisionRectangle().getUpperLeft().getX() - 25, 530), 50, 20), color);
    }

    public void moveRight() {
        this.block = new Block(new Rectangle(new Point(this.block.getCollisionRectangle().getUpperLeft().getX() + 25, 530), 50, 20), color);
    }

    // Sprite
    public void timePassed() {
        if (this.keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            this.moveLeft();
        } else if (this.keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            moveRight();
        }
    }

    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        Rectangle rect = this.block.getCollisionRectangle();
        Point upperLeft = rect.getUpperLeft();
        d.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), (int) rect.getWidth(), (int) rect.getHeight());
        d.setColor(Color.black);
        d.drawRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), (int) rect.getWidth(), (int) rect.getHeight());
    }

    // Collidable
    public Rectangle getCollisionRectangle() {
        return this.block.getCollisionRectangle();
    }

    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        // if the collision is with a horizontal side of the "Block" (can be also with a vertical side)
        if ((int) this.block.getCollisionRectangle().getUpperLeft().getY() == (int) collisionPoint.getY() ||
                (int) this.block.getCollisionRectangle().lowerLeft().getY() == (int) collisionPoint.getY()) {
            currentVelocity = new Velocity(currentVelocity.getDx(), (-1) * currentVelocity.getDy());
            //currentVelocity = new Velocity((-1) * currentVelocity.getDx(), currentVelocity.getDy());
        }

        // if the collision is with a vertical side of the "Block" (can be also with a horizontal side)
        if ((int) this.block.getCollisionRectangle().getUpperLeft().getX() == (int) collisionPoint.getX() ||
                (int) this.block.getCollisionRectangle().upperRight().getX() == (int) collisionPoint.getX()) {
            currentVelocity = new Velocity((-1) * currentVelocity.getDx(), currentVelocity.getDy());
            //currentVelocity = new Velocity(currentVelocity.getDx(), (-1) * currentVelocity.getDy());
        }

        return currentVelocity;
    }

    // Add this paddle to the game.
    public void addToGame(Game g) {
        g.getEnvironment().getCollidableList().remove(g.getEnvironment().getCollidableList().size() - 1);
        g.addCollidable(block);
    }

}