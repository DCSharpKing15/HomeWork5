import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.*;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        GUI gui = new GUI("title", 1000, 1000);
        Sleeper sleeper = new Sleeper();

        Ball b = new Ball(90, 90, 3, Color.red);
        b.setVelocity(Velocity.fromAngleAndSpeed(45, 7 * Math.sqrt(2)));
        b.setEndPerimeterX(1000);
        b.setStartPerimeterX(0);
        b.setEndPerimeterY(1000);
        b.setStartPerimeterY(0);

        GameEnvironment gameEnvironment = new GameEnvironment();

        Rectangle rectangle1 = new Rectangle(new Point(100, 800), 50, 150);
        Rectangle rectangle2 = new Rectangle(new Point(150, 130), 600, 600);
        Rectangle rectangle3 = new Rectangle(new Point(700, 600), 200, 300);
        Rectangle rectangle4 = new Rectangle(new Point(50, 50), 400, 30);

        Block block1 = new Block(rectangle1, Color.red);
        Block block2 = new Block(rectangle2, Color.blue);
        Block block3 = new Block(rectangle3, Color.yellow);
        Block block4 = new Block(rectangle4, Color.green);

        gameEnvironment.addCollidable(block1);
        gameEnvironment.addCollidable(block2);
        gameEnvironment.addCollidable(block3);
        gameEnvironment.addCollidable(block4);

        b.setGameEnvironment(gameEnvironment);

        while (true) {
            DrawSurface d = gui.getDrawSurface();
            block1.drawOn(d);
            block2.drawOn(d);
            block3.drawOn(d);
            block4.drawOn(d);
            b.moveOneStep();
            b.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(10);  // wait for 50 milliseconds.
        }
    }
}
